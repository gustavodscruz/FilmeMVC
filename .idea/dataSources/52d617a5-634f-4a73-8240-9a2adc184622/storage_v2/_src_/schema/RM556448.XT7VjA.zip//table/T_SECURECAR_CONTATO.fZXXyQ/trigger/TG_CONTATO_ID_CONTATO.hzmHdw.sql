create trigger TG_CONTATO_ID_CONTATO
    before insert
    on T_SECURECAR_CONTATO
    for each row
    when (new.id_contato IS NULL)
BEGIN
    :new.id_contato := t_securecar_contato_id_contato.nextval;
END;
/

