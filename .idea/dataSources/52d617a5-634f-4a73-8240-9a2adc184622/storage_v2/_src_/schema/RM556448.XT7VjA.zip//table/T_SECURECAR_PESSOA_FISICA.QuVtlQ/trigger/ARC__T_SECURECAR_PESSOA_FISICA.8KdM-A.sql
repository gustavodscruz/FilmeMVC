create trigger ARC__T_SECURECAR_PESSOA_FISICA
    before insert or update of ID_PESSOA
    on T_SECURECAR_PESSOA_FISICA
    for each row
DECLARE
    d NUMBER(9);
BEGIN
    SELECT
        a.id_pessoa
    INTO d
    FROM
        t_securecar_pessoa a
    WHERE
        a.id_pessoa = :new.id_pessoa;

    IF ( d IS NULL OR d <> d ) THEN
        raise_application_error(-20223, 'FK Relation_45 in Table T_SECURECAR_PESSOA_FISICA violates Arc constraint on Table T_SECURECAR_PESSOA - discriminator column ID_PESSOA doesn''t have value fisico');
    END IF;

EXCEPTION
    WHEN no_data_found THEN
        NULL;
    WHEN OTHERS THEN
        RAISE;
END;
/

