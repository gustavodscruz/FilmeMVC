create trigger TG_PECAS_CONSERTO_ID_
    before insert
    on T_SECURECAR_PECAS_CONSERTO
    for each row
    when (new.id_peca IS NULL)
BEGIN
    :new.id_peca := t_securecar_pecas_conserto_id_.nextval;
END;
/

