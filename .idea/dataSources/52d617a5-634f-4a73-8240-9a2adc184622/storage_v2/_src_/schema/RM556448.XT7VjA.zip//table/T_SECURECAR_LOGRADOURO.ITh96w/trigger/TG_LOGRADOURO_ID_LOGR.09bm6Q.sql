create trigger TG_LOGRADOURO_ID_LOGR
    before insert
    on T_SECURECAR_LOGRADOURO
    for each row
    when (new.id_logradouro IS NULL)
BEGIN
    :new.id_logradouro := t_securecar_logradouro_id_logr.nextval;
END;
/

