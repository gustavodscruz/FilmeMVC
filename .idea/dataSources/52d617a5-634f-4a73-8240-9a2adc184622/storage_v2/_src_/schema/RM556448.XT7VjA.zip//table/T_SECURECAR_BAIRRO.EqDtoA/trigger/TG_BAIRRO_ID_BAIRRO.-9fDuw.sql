create trigger TG_BAIRRO_ID_BAIRRO
    before insert
    on T_SECURECAR_BAIRRO
    for each row
    when (new.id_bairro IS NULL)
BEGIN
    :new.id_bairro := t_securecar_bairro_id_bairro.nextval;
END;
/

