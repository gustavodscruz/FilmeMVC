create trigger TG_ID_PESSOA
    before insert
    on T_SECURECAR_PESSOA
    for each row
    when (new.id_pessoa IS NULL)
BEGIN
    :new.id_pessoa := t_securecar_pessoa_id_pessoa.nextval;
END;
/

