create trigger TG_INCIDENTE_ID_INCID
    before insert
    on T_SECURECAR_INCIDENTE
    for each row
    when (new.id_incidente IS NULL)
BEGIN
    :new.id_incidente := t_securecar_incidente_id_incid.nextval;
END;
/

