create trigger TG_CONSERTO_ID_CONCER
    before insert
    on T_SECURECAR_CONSERTO
    for each row
    when (new.id_concerto IS NULL)
BEGIN
    :new.id_concerto := t_securecar_conserto_id_concer.nextval;
END;
/

