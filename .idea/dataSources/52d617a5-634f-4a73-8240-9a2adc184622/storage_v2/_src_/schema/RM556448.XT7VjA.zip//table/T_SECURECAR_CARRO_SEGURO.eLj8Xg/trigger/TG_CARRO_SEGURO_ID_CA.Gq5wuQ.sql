create trigger TG_CARRO_SEGURO_ID_CA
    before insert
    on T_SECURECAR_CARRO_SEGURO
    for each row
    when (new.id_carro_seguro IS NULL)
BEGIN
    :new.id_carro_seguro := t_securecar_carro_seguro_id_ca.nextval;
END;
/

