create trigger TG_CIDADE_ID_CIDADE
    before insert
    on T_SECURECAR_CIDADE
    for each row
    when (new.id_cidade IS NULL)
BEGIN
    :new.id_cidade := t_securecar_cidade_id_cidade.nextval;
END;
/

