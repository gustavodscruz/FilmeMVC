create trigger TG_ESTADO_ID_ESTADO
    before insert
    on T_SECURECAR_ESTADO
    for each row
    when (new.id_estado IS NULL)
BEGIN
    :new.id_estado := t_securecar_estado_id_estado.nextval;
END;
/

