create trigger TG_PAIS_ID_PAIS_TRG
    before insert
    on T_SECURECAR_PAIS
    for each row
    when (new.id_pais IS NULL)
BEGIN
    :new.id_pais := t_securecar_pais_id_pais_seq.nextval;
END;
/

